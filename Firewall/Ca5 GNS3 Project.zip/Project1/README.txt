Project: 'Project1' created on 2025-03-17
Author: John Doe <john.doe@example.com>

No project description was given